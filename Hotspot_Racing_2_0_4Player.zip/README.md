# Hotspot Racing 2.0

Android local multiplayer racing prototype.

### Added
- Automatic LAN/Hotspot host discovery via UDP broadcast
- Up to 4 cars
- 3-2-1-GO countdown
- Basic car collision
- Winner screen
- No Internet required

### Test
1. Build/install the APK on Android phones.
2. Host phone turns on its Wi-Fi hotspot.
3. Other phones connect to that hotspot.
4. Host taps CREATE RACE.
5. Other phones tap FIND & JOIN RACE.
6. The host should appear automatically.

Note: Android manufacturers can restrict client-to-client traffic or broadcast packets on some hotspot implementations. This prototype uses standard local UDP discovery and TCP gameplay; a production version should use Android NSD/Wi-Fi Direct or a more robust discovery fallback.
