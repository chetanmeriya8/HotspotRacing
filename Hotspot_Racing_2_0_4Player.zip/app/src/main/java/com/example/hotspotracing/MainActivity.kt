package com.example.hotspotracing

import android.app.*
import android.os.*
import android.graphics.*
import android.view.*
import android.widget.*
import java.net.*
import java.io.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread
import kotlin.math.*

data class NetCar(var x:Float,var y:Float,var color:Int,var name:String,var finished:Boolean=false)

class MainActivity:Activity(){
    private lateinit var view:RaceView
    private var host:Host?=null
    private var client:Client?=null
    private val port=40404
    private var myId=0

    override fun onCreate(b:Bundle?){super.onCreate(b);menu()}

    private fun menu(){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(50,20,50,20);setBackgroundColor(Color.rgb(15,18,22))}
        val t=TextView(this).apply{text="🏎️ HOTSPOT RACING 2.0";textSize=30f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        val d=TextView(this).apply{text="4 PLAYERS • AUTO DISCOVERY • COLLISION";textSize=16f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER}
        val h=Button(this).apply{text="CREATE RACE (HOST)"}
        val j=Button(this).apply{text="FIND & JOIN RACE"}
        l.addView(t);l.addView(d);l.addView(h,LinearLayout.LayoutParams(-1,75));l.addView(j,LinearLayout.LayoutParams(-1,75));setContentView(l)
        h.setOnClickListener{
            myId=0
            host=Host(port){msg->runOnUiThread{view.onNet(msg)}}
            host!!.start()
            start(true)
        }
        j.setOnClickListener{discover()}
    }

    private fun discover(){
        val dialog=ProgressDialog(this).apply{setTitle("Finding race…");setMessage("Searching local Wi‑Fi");setCancelable(true);show()}
        thread{
            val found=mutableListOf<String>()
            try{
                val ds=DatagramSocket().apply{broadcast=true;soTimeout=700}
                val data="RACE_DISCOVER".toByteArray()
                ds.send(DatagramPacket(data,data.size,InetAddress.getByName("255.255.255.255"),40405))
                val end=System.currentTimeMillis()+2500
                while(System.currentTimeMillis()<end){
                    try{
                        val b=ByteArray(128);val p=DatagramPacket(b,b.size);ds.receive(p)
                        val s=String(p.data,0,p.length)
                        if(s.startsWith("RACE_HERE:")&&!found.contains(p.address.hostAddress))found.add(p.address.hostAddress)
                    }catch(_:Exception){}
                };ds.close()
            }catch(_:Exception){}
            runOnUiThread{dialog.dismiss();if(found.isEmpty()) Toast.makeText(this,"No host found. Make sure both phones are on the same hotspot.",Toast.LENGTH_LONG).show()
            else chooseHost(found)}
        }
    }

    private fun chooseHost(list:List<String>){
        val names=list.map{"🏁 Race Host — $it"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Races Found").setItems(names){_,which->
            client=Client(list[which],port){m->runOnUiThread{view.onNet(m)}}
            client!!.start()
            myId=1
            start(false)
        }.setNegativeButton("Cancel",null).show()
    }

    private fun start(isHost:Boolean){
        view=RaceView(this,isHost,myId)
        view.send={dx->if(isHost)host?.localControl(dx) else client?.send("CTRL,$dx")}
        setContentView(view)
    }
    override fun onDestroy(){host?.stop();client?.stop();super.onDestroy()}
}

class RaceView(ctx:android.content.Context,private val isHost:Boolean,var id:Int):View(ctx){
    var send:((Int)->Unit)?=null
    val cars=Array(4){i->NetCar(.18f+i*.21f,.82f, arrayOf(Color.RED,Color.CYAN,Color.YELLOW,Color.MAGENTA)[i],"P${i+1}")}
    var state="LOBBY";var countdown=3;var score=0;var winner=-1
    var left=false;var right=false;var last=System.currentTimeMillis();var finishLine=.12f

    override fun onDraw(c:Canvas){
        val w=width.toFloat();val h=height.toFloat()
        c.drawColor(Color.rgb(35,130,60))
        val p=Paint(1);p.color=Color.DKGRAY;c.drawRect(w*.08f,0,w*.92f,h,p)
        p.color=Color.WHITE;p.strokeWidth=7f
        for(x in 1..3)c.drawLine(w*(.08f+x*.21f),0,w*(.08f+x*.21f),h,p)
        p.color=Color.LTGRAY;c.drawRect(w*.08f,h*.13f,w*.92f,h*.16f,p)
        p.color=Color.BLACK;p.textSize=22f;c.drawText("PLAYERS  ${cars.count{it.y<.99f}}/4",20,35,p)
        p.color=Color.WHITE;p.textSize=28f;c.drawText(if(winner>=0)"WINNER: ${cars[winner].name}" else "RACE • P${id+1}",20,68,p)
        for((i,car) in cars.withIndex()){
            val x=car.x*w;val y=car.y*h
            p.color=car.color;c.drawRoundRect(x-28,y-50,x+28,y+50,14f,14f,p)
            p.color=Color.BLACK;c.drawCircle(x-18,y-28,8f,p);c.drawCircle(x+18,y-28,8f,p)
            p.color=Color.WHITE;p.textSize=16f;c.drawText(car.name,x-12,y+6,p)
        }
        if(state=="COUNTDOWN"){
            p.color=Color.WHITE;p.textSize=100f;p.textAlign=Paint.Align.CENTER
            c.drawText(if(countdown>0)countdown.toString() else "GO!",w/2,h/2,p);p.textAlign=Paint.Align.LEFT
        }
        if(state=="FINISH"){
            p.color=Color.WHITE;p.textSize=52f;p.textAlign=Paint.Align.CENTER
            c.drawText("🏆 ${cars[winner].name} WINS!",w/2,h*.42f,p);p.textAlign=Paint.Align.LEFT
        }
        p.color=0x66FFFFFF;c.drawCircle(w*.17f,h*.86f,65f,p);c.drawCircle(w*.36f,h*.86f,65f,p)
        p.color=Color.BLACK;p.textSize=50f;c.drawText("←",w*.14f,h*.89f,p);c.drawText("→",w*.33f,h*.89f,p)
        val now=System.currentTimeMillis();val dt=(now-last)/1000f;last=now
        if(state=="RACE"){score+=(dt*10).toInt()}
        invalidate()
    }

    fun onNet(m:String){
        when{
            m.startsWith("STATE,") -> {
                val a=m.split(",");var k=1
                for(i in 0..3) if(k+1<a.size){cars[i].x=a[k++].toFloat();cars[i].y=a[k++].toFloat()}
                state="RACE"
            }
            m.startsWith("COUNT,")-> {countdown=m.substringAfter(",").toInt();state="COUNTDOWN"}
            m.startsWith("WIN,")-> {winner=m.substringAfter(",").toInt();state="FINISH"}
        }
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action==MotionEvent.ACTION_DOWN||e.action==MotionEvent.ACTION_MOVE){
            val d=if(e.x<width*.27f)-1 else if(e.x<width*.48f)1 else 0
            send?.invoke(d);return true
        }
        if(e.action==MotionEvent.ACTION_UP){send?.invoke(0);return true};return true
    }
}

class Host(private val port:Int,val out:(String)->Unit){
    private var run=true;private lateinit var ss:ServerSocket
    private val clients=CopyOnWriteArrayList<Socket>();private val x=FloatArray(4){.18f+it*.21f}
    fun start()=thread{
        thread{discoverResponder()}
        try{ss=ServerSocket(port);startRaceLoop();while(run){val s=ss.accept();clients.add(s);thread{read(s,clients.size)}}}catch(_:Exception){}
    }
    private fun discoverResponder(){
        try{val ds=DatagramSocket(40405);while(run){val b=ByteArray(64);val p=DatagramPacket(b,b.size);ds.receive(p)
            val msg="RACE_HERE:HOTSPOT_RACING".toByteArray();ds.send(DatagramPacket(msg,msg.size,p.address,p.port))};ds.close()}catch(_:Exception){}
    }
    private fun read(s:Socket,n:Int){
        try{val r=s.getInputStream().bufferedReader();while(run){val m=r.readLine()?:break;if(m.startsWith("CTRL"))move(n.coerceIn(1,3),m.split(",")[1].toInt())}}catch(_:Exception){}
    }
    fun localControl(d:Int){move(0,d)}
    private fun move(i:Int,d:Int){x[i]=(x[i]+d*.012f).coerceIn(.11f,.89f);collision(i);if(x[i]>.88f){broadcast("WIN,$i")}}
    private fun collision(i:Int){for(j in 0..3)if(j!=i&&abs(x[i]-x[j])<.055f)x[i]+=(if(x[i]<x[j])-.06f else .06f)}
    private fun broadcast(m:String){clients.forEach{try{it.getOutputStream().write((m+"\n").toByteArray());it.getOutputStream().flush()}catch(_:Exception){}};out(m)}
    private fun startRaceLoop()=thread{
        for(n in 3 downTo 1){broadcast("COUNT,$n");Thread.sleep(1000)}
        broadcast("COUNT,0");Thread.sleep(400)
        while(run){broadcast("STATE,"+x.joinToString(","){ "$it,.82" });Thread.sleep(60)}
    }
    fun stop(){run=false;try{ss.close()}catch(_:Exception){};clients.forEach{try{it.close()}catch(_:Exception){}}}
}

class Client(private val host:String,private val port:Int,val out:(String)->Unit){
    private var s:Socket?=null;private var run=true
    fun start()=thread{try{s=Socket(host,port);val r=s!!.getInputStream().bufferedReader();while(run){val m=r.readLine()?:break;out(m)}}catch(_:Exception){}}
    fun send(m:String)=thread{try{s?.getOutputStream()?.write((m+"\n").toByteArray());s?.getOutputStream()?.flush()}catch(_:Exception){}}
    fun stop(){run=false;try{s?.close()}catch(_:Exception){}}
}
