plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.example.hotspotracing"; compileSdk=35
    defaultConfig { applicationId="com.example.hotspotracing"; minSdk=26; targetSdk=35; versionCode=2; versionName="2.0" }
}
